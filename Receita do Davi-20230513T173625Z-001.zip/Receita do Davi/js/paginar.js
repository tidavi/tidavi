<script>
  const pagination = document.querySelector('.pagination');
  const pages = pagination.querySelectorAll('.page-link');
  const content = document.querySelector('.content');
  
  pages.forEach(page => {
    page.addEventListener('click', (e) => {
      e.preventDefault();
      content.innerHTML = `Conteúdo da página ${page.innerHTML}`;
      pages.forEach(page => page.parentElement.classList.remove('active'));
      page.parentElement.classList.add('active');
    });
  });
</script>